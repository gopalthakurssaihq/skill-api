/**
* EmployeeSkillController
* @typedef {import('./employeeskill.controller')} EmployeeSkillController
*/

/**
* EmployeeSkillService
* @typedef {import('./employeeskill.service')} EmployeeSkillService
*/

/**
* EmployeeSkillValidator
* @typedef {import('./employeeskill.validator')} EmployeeSkillValidator
*/