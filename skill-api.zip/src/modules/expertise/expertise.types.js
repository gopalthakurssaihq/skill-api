/**
* ExpertiseController
* @typedef {import('./expertise.controller')} ExpertiseController
*/

/**
* ExpertiseService
* @typedef {import('./expertise.service')} ExpertiseService
*/

/**
* ExpertiseValidator
* @typedef {import('./expertise.validator')} ExpertiseValidator
*/