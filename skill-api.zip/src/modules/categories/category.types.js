/**
* CategoryController
* @typedef {import('./category.controller')} CategoryController
*/

/**
* CategoryService
* @typedef {import('./category.service')} CategoryService
*/

/**
* CategoryValidator
* @typedef {import('./category.validator')} CategoryValidator
*/