/**
 * RoleController
 * @typedef {import('./role.controller')} RoleController
 */

/**
 * RoleService
 * @typedef {import('./role.service')} RoleService
 */

/**
 * RoleValidator
 * @typedef {import('./role.validator')} RoleValidator
 */
