/**
 * ModuleToRoleController
 * @typedef {import('./mtr.module')} ModuleToRoleController
 */

/**
 * ModuleToRoleService
 * @typedef {import('./mtr.service')} ModuleToRoleService
 */

/**
 * ModuleToRoleValidator
 * @typedef {import('./mtr.validator')} ModuleToRoleValidator
 */
